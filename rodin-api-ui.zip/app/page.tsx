import Rodin from "@/components/rodin"

export default function Home() {
  return (
    <main className="h-[100dvh] w-screen overflow-hidden bg-black bg-radial-gradient">
      <Rodin />
    </main>
  )
}
