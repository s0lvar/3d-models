"use client"

export default function LoadingPlaceholder() {
  // We're not using this anymore since we're using the Spline model
  // But keeping it for compatibility with existing code
  return null
}
