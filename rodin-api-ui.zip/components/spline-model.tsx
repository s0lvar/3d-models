"use client"

import Spline from "@splinetool/react-spline/next"

export default function SplineModel() {
  return (
    <div className="w-full h-full">
      <Spline scene="https://prod.spline.design/e-PXiglzjZyXK9CB/scene.splinecode" />
    </div>
  )
}
