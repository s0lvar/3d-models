"use client"

import { Canvas } from "@react-three/fiber"
import { OrbitControls, Environment } from "@react-three/drei"
import { Suspense } from "react"
import SceneSetup from "./scene-setup"
import ModelComponent from "./model-component"
import SplineModel from "./spline-model"

export default function ModelViewer({ modelUrl }: { modelUrl: string | null }) {
  // If we have a model URL, show the generated model
  // Otherwise, show the Spline model as a placeholder
  if (modelUrl) {
    return (
      <div className="w-full h-[100dvh] bg-black bg-radial-gradient">
        <Canvas camera={{ position: [0, 0, 5], fov: 50 }}>
          <color attach="background" args={["#000000"]} />
          <SceneSetup />
          <ambientLight intensity={0.3} />
          <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} castShadow intensity={1} />
          <pointLight position={[-10, -10, -10]} intensity={0.5} />

          <Suspense fallback={null}>
            <ModelComponent url={modelUrl} />
          </Suspense>

          <OrbitControls
            minDistance={3}
            maxDistance={10}
            enableZoom={true}
            enablePan={false}
            autoRotate={true}
            autoRotateSpeed={1}
          />
          <Environment preset="city" background={false} />
        </Canvas>
      </div>
    )
  }

  // Show the Spline model when no generated model is available
  return (
    <div className="w-full h-[100dvh] bg-black bg-radial-gradient">
      <SplineModel />
    </div>
  )
}
