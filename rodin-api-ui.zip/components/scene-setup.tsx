"use client"

import { useEffect } from "react"
import { useThree } from "@react-three/fiber"

export default function SceneSetup() {
  const { scene } = useThree()

  useEffect(() => {
    // We're now setting the background color directly in the Canvas
    // so we don't need to set it to null here
  }, [scene])

  return null
}
